# Internal monitoring agent

Run this agent **inside the authorized network** when a monitor must reach localhost or a private address. The hosted dashboard never receives a URL to fetch on the agent's behalf.

1. Copy `config.example.json` to `config.json`.
2. Add only targets approved for this agent. Set `allowPrivate: true` on each private or loopback monitor.
3. Set `AGENT_SHARED_SECRET` when `ingestUrl` is enabled.
4. Run `node agents/internal-monitor.mjs agents/config.json`.

The agent has no listening port. It reads a static configuration, runs bounded checks, and optionally sends signed results outward. It always rejects link-local, multicast, and known metadata addresses.

Each monitor may set `requestsPerSecond` from greater than zero through 300, `samples` through 100, and `concurrency` through 20. The example runs at 300 probe starts per second for 60 samples.
