import { createHmac } from "node:crypto";
import { readFile } from "node:fs/promises";
import { isIP } from "node:net";
import { lookup } from "node:dns/promises";
import { runProbeBatch } from "../lib/runner.mjs";

const configPath = process.argv[2] || new URL("./config.json", import.meta.url);
const config = JSON.parse(await readFile(configPath, "utf8"));

function forbiddenAddress(address) {
  if (address === "169.254.169.254" || address === "100.100.100.200") return "metadata_address_forbidden";
  if (address.includes(":")) {
    const value = address.toLowerCase();
    if (value === "::1") return null;
    if (value.startsWith("fe80:")) return "link_local_forbidden";
    if (value.startsWith("ff")) return "multicast_forbidden";
    return null;
  }
  const [a,b] = address.split(".").map(Number);
  if (a >= 224) return "multicast_forbidden";
  if (a === 169 && b === 254) return "link_local_forbidden";
  return null;
}

function isPrivateAddress(address) {
  if (address === "::1") return true;
  if (!isIP(address) || address.includes(":")) return false;
  const [a,b] = address.split(".").map(Number);
  return a === 10 || a === 127 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
}

async function authorizeMonitor(monitor) {
  if (!monitor.id || !monitor.url) throw new Error("monitor_id_and_url_required");
  const url = new URL(monitor.url);
  if (!["http:","https:"].includes(url.protocol) || url.username || url.password) throw new Error("invalid_monitor_url");
  const addresses = await lookup(url.hostname, { all: true, verbatim: true });
  if (!addresses.length) throw new Error("dns_resolution_empty");
  for (const { address } of addresses) {
    const forbidden = forbiddenAddress(address);
    if (forbidden) throw new Error(forbidden);
    if (isPrivateAddress(address) && monitor.allowPrivate !== true) throw new Error("private_target_requires_explicit_flag");
  }
  return { ...monitor, url: url.toString(), addresses: addresses.map(value => value.address) };
}

async function deliver(payload) {
  if (!config.ingestUrl) { process.stdout.write(`${JSON.stringify(payload)}\n`); return; }
  const body = JSON.stringify(payload);
  const timestamp = String(Date.now());
  const signature = createHmac("sha256", process.env.AGENT_SHARED_SECRET || "").update(`${timestamp}.${body}`).digest("hex");
  const response = await fetch(config.ingestUrl, { method: "POST", headers: { "content-type": "application/json", "x-agent-id": config.agentId, "x-agent-timestamp": timestamp, "x-agent-signature": signature }, body });
  if (!response.ok) throw new Error(`ingest_rejected_${response.status}`);
}

async function runMonitor(rawMonitor) {
  const monitor = await authorizeMonitor(rawMonitor);
  const sampleCount = Number(monitor.samples || 60);
  const concurrency = Number(monitor.concurrency || 12);
  const requestsPerSecond = Number(monitor.requestsPerSecond || 300);
  if (!Number.isInteger(sampleCount) || sampleCount < 1 || sampleCount > 100) throw new Error("sample_count_out_of_range");
  if (!Number.isInteger(concurrency) || concurrency < 1 || concurrency > 20) throw new Error("concurrency_out_of_range");
  if (!Number.isFinite(requestsPerSecond) || requestsPerSecond <= 0 || requestsPerSecond > 300) throw new Error("request_rate_out_of_range");
  const report = await runProbeBatch({ targets: [{ url: monitor.url, host: new URL(monitor.url).hostname, kind: "network" }], sampleCount, concurrency, requestsPerSecond }, { maxRunMs: Math.min(25_000, Number(monitor.maxRunMs || 25_000)) });
  await deliver({ agentId: config.agentId, monitorId: monitor.id, targetLabel: monitor.label, resolvedAddresses: monitor.addresses, completedAt: report.completedAt, samples: report.byTarget[0].samples });
}

async function cycle() {
  for (const monitor of config.monitors || []) {
    try { await runMonitor(monitor); } catch (error) { process.stderr.write(`${new Date().toISOString()} ${monitor.id || "unknown"} ${error.message}\n`); }
  }
}

await cycle();
if (config.runOnce !== true) setInterval(() => void cycle(), Math.max(30_000, config.intervalMs || 60_000));
