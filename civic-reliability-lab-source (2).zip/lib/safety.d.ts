export type ValidationResult={ok:false;reason:string}|{ok:true;url:URL;host:string};
export function isPrivateIPv4(hostname:string):boolean;
export function validateTarget(rawUrl:string,allowedHosts:string[]):ValidationResult;
export function validateFixtureTarget(rawUrl:string,allowedFixtures:string[]):{ok:false;reason:string}|{ok:true;url:URL;name:string};
export function validateInjectionTarget(rawUrl:string,stagingHosts:string[]):ValidationResult;
export function evaluateTargets(observed:Record<string,number>,targets:Record<string,number>):{checks:Record<string,boolean>;passed:number;total:number;overall:"PASS"|"FAIL"};
