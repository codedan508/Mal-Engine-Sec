export type ValidatedRun={ok:true;targets:Array<{url:string;host:string;kind:"network"|"fixture"}>;sampleCount:number;concurrency:number;requestsPerSecond:number};
export const RUN_LIMITS:{readonly maxTargets:number;readonly maxSamplesPerTarget:number;readonly maxConcurrency:number;readonly maxRequestsPerSecond:number;readonly maxRunMs:number};
export function percentile(values:number[],rank:number):number|null;
export function summarizeSamples(samples:Array<Record<string,unknown>>):Record<string,unknown>;
export function validateRunRequest(input:unknown,allowedHosts:string[],allowedFixtures?:string[]):ValidatedRun|{ok:false;reason:string};
export function runProbeBatch(config:ValidatedRun,options?:{fetchImpl?:typeof fetch;maxRunMs?:number}):Promise<Record<string,unknown>>;
