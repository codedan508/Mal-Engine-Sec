CREATE TABLE `alert_rules` (
	`id` text PRIMARY KEY NOT NULL,
	`monitor_id` text NOT NULL,
	`metric` text NOT NULL,
	`operator` text NOT NULL,
	`threshold` real NOT NULL,
	`consecutive_failures` integer DEFAULT 1 NOT NULL,
	`enabled` integer DEFAULT true NOT NULL
);
--> statement-breakpoint
CREATE TABLE `audit_logs` (
	`id` text PRIMARY KEY NOT NULL,
	`actor_id` text NOT NULL,
	`role` text NOT NULL,
	`action` text NOT NULL,
	`target` text,
	`outcome` text NOT NULL,
	`reason` text,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `check_results` (
	`id` text PRIMARY KEY NOT NULL,
	`monitor_id` text NOT NULL,
	`checked_at` text NOT NULL,
	`status` text NOT NULL,
	`http_status` integer,
	`response_ms` integer,
	`value` real,
	`detail` text,
	`screenshot_key` text
);
--> statement-breakpoint
CREATE TABLE `monitors` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`url` text NOT NULL,
	`check_type` text NOT NULL,
	`interval_seconds` integer NOT NULL,
	`enabled` integer DEFAULT true NOT NULL,
	`created_by` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_monitors_url_type` ON `monitors` (`url`,`check_type`);--> statement-breakpoint
CREATE TABLE `role_assignments` (
	`user_id` text PRIMARY KEY NOT NULL,
	`role` text NOT NULL,
	`assigned_at` text NOT NULL,
	`assigned_by` text NOT NULL
);
