import { NextRequest, NextResponse } from "next/server";
import { getDb } from "../../../db";
import { auditLogs, checkResults } from "../../../db/schema";
export const dynamic = "force-dynamic";

function configuredList(name: string) { return (process.env[name] || "").split(",").map(value => value.trim()).filter(Boolean); }
function fromHex(value: string) { if (!/^[0-9a-f]{64}$/i.test(value)) return null; return Uint8Array.from(value.match(/.{2}/g)!.map(byte => Number.parseInt(byte, 16))); }
async function validSignature(secret: string, timestamp: string, body: string, supplied: string) {
  const signature = fromHex(supplied); if (!signature) return false;
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  return crypto.subtle.verify("HMAC", key, signature, new TextEncoder().encode(`${timestamp}.${body}`));
}

export async function POST(request: NextRequest) {
  const secret = process.env.AGENT_SHARED_SECRET;
  if (!secret) return NextResponse.json({ error: "agent_ingest_not_configured" }, { status: 503 });
  const agentId = request.headers.get("x-agent-id") || "";
  const timestamp = request.headers.get("x-agent-timestamp") || "";
  const signature = request.headers.get("x-agent-signature") || "";
  if (!configuredList("INTERNAL_AGENT_IDS").includes(agentId)) return NextResponse.json({ error: "agent_not_authorized" }, { status: 403 });
  const sentAt = Number(timestamp);
  if (!Number.isFinite(sentAt) || Math.abs(Date.now() - sentAt) > 300_000) return NextResponse.json({ error: "stale_agent_message" }, { status: 401 });
  const raw = await request.text();
  if (raw.length > 100_000 || !(await validSignature(secret, timestamp, raw, signature))) return NextResponse.json({ error: "invalid_agent_signature" }, { status: 401 });
  let payload: { agentId?: string; monitorId?: string; targetLabel?: string; completedAt?: string; samples?: Array<{ pass?: boolean; status?: number; responseTimeMs?: number; error?: string }> };
  try { payload = JSON.parse(raw); } catch { return NextResponse.json({ error: "invalid_json" }, { status: 400 }); }
  if (payload.agentId !== agentId || !payload.monitorId || !configuredList("INTERNAL_MONITOR_IDS").includes(payload.monitorId)) return NextResponse.json({ error: "monitor_not_authorized" }, { status: 403 });
  if (!Array.isArray(payload.samples) || payload.samples.length < 1 || payload.samples.length > 30) return NextResponse.json({ error: "invalid_samples" }, { status: 400 });
  const passed = payload.samples.filter(sample => sample.pass === true).length;
  const timings = payload.samples.map(sample => Number(sample.responseTimeMs)).filter(Number.isFinite).sort((a,b) => a-b);
  const p95 = timings[Math.max(0, Math.ceil(timings.length * .95) - 1)] ?? null;
  const now = new Date().toISOString();
  const db = getDb();
  await db.batch([
    db.insert(checkResults).values({ id: crypto.randomUUID(), monitorId: payload.monitorId, checkedAt: payload.completedAt || now, status: passed === payload.samples.length ? "pass" : "fail", responseMs: p95, value: Number(((passed / payload.samples.length) * 100).toFixed(3)), detail: JSON.stringify({ agentId, targetLabel: payload.targetLabel || payload.monitorId, samples: payload.samples.length }) }),
    db.insert(auditLogs).values({ id: crypto.randomUUID(), actorId: agentId, role: "internal-agent", action: "submit_monitor_results", target: payload.monitorId, outcome: "accepted", createdAt: now }),
  ]);
  return NextResponse.json({ accepted: true, monitorId: payload.monitorId, sampleCount: payload.samples.length });
}
