import { NextRequest, NextResponse } from "next/server";
import { env } from "cloudflare:workers";
import { runProbeBatch, validateRunRequest } from "../../../lib/runner.mjs";
export const dynamic = "force-dynamic";

function allowedHosts() { return (process.env.ALLOWED_HOSTS || "").split(",").map(value => value.trim().toLowerCase()).filter(Boolean); }
function allowedFixtures() { return (process.env.ALLOWED_FIXTURES || "healthy,flaky-payment,slow-permit").split(",").map(value => value.trim().toLowerCase()).filter(Boolean); }
function hasOperatorRole(actor: string) { const configured = (process.env.LAB_OPERATOR_IDS || "").split(",").map(value => value.trim()).filter(Boolean); return configured.length === 0 || configured.includes(actor); }
async function acquireTargetLeases(hosts: string[], ownerId: string) {
  const now = Date.now(); const expiresAt = now + 30_000;
  for (const host of hosts) {
    const acquired = await env.DB.prepare(`INSERT INTO run_leases (host, owner_id, expires_at) VALUES (?, ?, ?) ON CONFLICT(host) DO UPDATE SET owner_id = excluded.owner_id, expires_at = excluded.expires_at WHERE run_leases.expires_at < ? RETURNING host`).bind(host, ownerId, expiresAt, now).first();
    if (!acquired) { await env.DB.prepare("DELETE FROM run_leases WHERE owner_id = ?").bind(ownerId).run(); return false; }
  }
  return true;
}
async function releaseTargetLeases(ownerId: string) { await env.DB.prepare("DELETE FROM run_leases WHERE owner_id = ?").bind(ownerId).run(); }

export async function POST(request: NextRequest) {
  const actor = request.headers.get("oai-authenticated-user-id");
  if (!actor) return NextResponse.json({ error: "authentication_required" }, { status: 401 });
  if (!hasOperatorRole(actor)) return NextResponse.json({ error: "operator_role_required" }, { status: 403 });
  const hosts = allowedHosts();
  const fixtures = allowedFixtures();
  if (hosts.length === 0 && fixtures.length === 0) return NextResponse.json({ error: "allowlist_not_configured" }, { status: 503 });
  let input: unknown;
  try { input = await request.json(); } catch { return NextResponse.json({ error: "invalid_json" }, { status: 400 }); }
  const config = validateRunRequest(input, hosts, fixtures);
  if (!config.ok) return NextResponse.json({ error: config.reason }, { status: 400 });
  const probeCount = config.targets.length * config.sampleCount;
  const networkHosts = [...new Set(config.targets.filter(target => target.kind === "network").map(target => target.host))];
  const ownerId = `${actor}:${crypto.randomUUID()}`;
  if (networkHosts.length && !(await acquireTargetLeases(networkHosts, ownerId))) return NextResponse.json({ error: "target_run_in_progress", retryAfterSeconds: 1 }, { status: 429 });
  try {
    const report = await runProbeBatch(config);
    return NextResponse.json(report, { headers: { "cache-control": "no-store", "x-probe-count": String(probeCount), "x-target-rate-limit": `${config.requestsPerSecond}/second` } });
  } finally { if (networkHosts.length) await releaseTargetLeases(ownerId); }
}

export async function GET(request: NextRequest) {
  const actor = request.headers.get("oai-authenticated-user-id");
  if (!actor) return NextResponse.json({ error: "authentication_required" }, { status: 401 });
  const hosts = allowedHosts();
  const fixtures = allowedFixtures();
  return NextResponse.json({ configured: hosts.length > 0 || fixtures.length > 0, hosts, fixtures, maxRequestsPerSecond: 300 });
}
