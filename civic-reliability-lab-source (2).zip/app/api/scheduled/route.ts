import { NextRequest, NextResponse } from "next/server";
import { runProbeBatch, validateRunRequest } from "../../../lib/runner.mjs";
export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  const expected = process.env.SCHEDULER_SECRET;
  if (!expected || request.headers.get("authorization") !== `Bearer ${expected}`) return NextResponse.json({ error: "scheduler_authentication_failed" }, { status: 401 });
  const hosts = (process.env.ALLOWED_HOSTS || "").split(",").map(value => value.trim()).filter(Boolean);
  const fixtures = (process.env.ALLOWED_FIXTURES || "healthy,flaky-payment,slow-permit").split(",").map(value => value.trim()).filter(Boolean);
  const targets = [...fixtures.map(name => `fixture://${name}`), ...hosts.map(host => `https://${host}/`)];
  const config = validateRunRequest({ targets, sampleCount: 60, concurrency: 12, requestsPerSecond: 300 }, hosts, fixtures);
  if (!config.ok) return NextResponse.json({ error: config.reason }, { status: 400 });
  return NextResponse.json(await runProbeBatch(config));
}
