import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "Civic Reliability Lab", description: "Authorized reliability monitoring for essential public web services.", icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" } };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
