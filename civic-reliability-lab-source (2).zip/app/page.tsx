"use client";

import { useEffect, useMemo, useState } from "react";
import { Activity, BarChart3, BellRing, Check, ChevronDown, CircleDot, Download, ExternalLink, FileCheck2, FlaskConical, Globe2, History, KeyRound, LockKeyhole, Menu, MoreHorizontal, Play, Plus, Radar, RefreshCw, Search, Settings2, ShieldCheck, Siren, Users, X } from "lucide-react";

type CheckResult = { id: number; service: string; type: string; status: "pass" | "warn" | "fail"; value: string; target: string; time: string; detail: string };
const initialResults: CheckResult[] = [
  { id: 1, service: "Resident Services", type: "HTTP", status: "pass", value: "200 · 184 ms", target: "< 750 ms", time: "13:42:08", detail: "Homepage returned expected content signature." },
  { id: 2, service: "Resident Services", type: "DNS", status: "pass", value: "34 ms", target: "< 100 ms", time: "13:42:07", detail: "A and AAAA records resolved through approved resolver." },
  { id: 3, service: "Permit journey", type: "Journey", status: "warn", value: "1.42 s", target: "< 1.20 s", time: "13:40:01", detail: "Search step exceeded its warning threshold." },
  { id: 4, service: "Resident Services", type: "TLS", status: "pass", value: "Valid · 81 days", target: "> 30 days", time: "13:39:58", detail: "Certificate chain valid; hostname matched." },
  { id: 5, service: "Payment fixture", type: "Recovery", status: "pass", value: "38 s", target: "< 60 s", time: "13:35:16", detail: "Local fixture recovered after controlled 503 injection." },
  { id: 6, service: "Benefits directory", type: "Links", status: "fail", value: "3 broken", target: "0 broken", time: "13:30:00", detail: "Three same-origin links returned 404 responses." },
];
const nav = [["Overview", Activity], ["Monitors", Radar], ["Journeys", Globe2], ["Incidents", Siren], ["Reports", BarChart3], ["Audit log", History]] as const;

export default function Home() {
  const [active, setActive] = useState("Overview");
  const [running, setRunning] = useState(false);
  const [notice, setNotice] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [showRules, setShowRules] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [results, setResults] = useState(initialResults);
  const [interval, setIntervalValue] = useState("5 minutes");
  const [requestsPerSecond, setRequestsPerSecond] = useState(300);
  const [fixtureArmed, setFixtureArmed] = useState(false);
  const [allowedTargets, setAllowedTargets] = useState<string[]>([]);
  const [targetUrl, setTargetUrl] = useState("");
  const overall = useMemo(() => results.some(r => r.status === "fail") ? "FAIL" : "PASS", [results]);

  async function runChecks() {
    if (running) return;
    if (!targetUrl) { setNotice("No authorized target is configured."); setShowNew(true); return; }
    setRunning(true); setNotice("Running repeated approved probes…");
    try {
      const response = await fetch("/api/check", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ targets: [targetUrl], sampleCount: 60, concurrency: 12, requestsPerSecond }) });
      const report = await response.json();
      if (!response.ok) throw new Error(report.error || "run_failed");
      const current = report.byTarget[0];
      const now = new Date(report.completedAt).toLocaleTimeString([], { hour12: false });
      setResults(rs => rs.map((r, i) => i === 0 ? { ...r, status: current.summary.failed ? "fail" : "pass", time: now, value: `${current.summary.uptimePercent}% · p95 ${current.summary.p95Ms ?? "—"} ms`, detail: `${current.summary.total} probes; ${current.summary.failed} failures.` } : r));
      setNotice(`Run completed: ${report.probeCount} probes, ${report.summary.uptimePercent}% successful.`);
    } catch (error) { setNotice(`Run blocked or failed: ${error instanceof Error ? error.message : "unknown_error"}`); }
    finally { setRunning(false); setTimeout(() => setNotice(""), 4500); }
  }

  useEffect(() => {
    const context = (document as Document & { modelContext?: { registerTool?: (tool: unknown, options?: unknown) => void } }).modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    context.registerTool({ name: "run_authorized_reliability_check", title: "Run authorized reliability check", description: "Run the configured allowlisted monitor and update the dashboard.", inputSchema: { type: "object", properties: { monitor: { type: "string", enum: ["resident-services"] } }, required: ["monitor"], additionalProperties: false }, annotations: { readOnlyHint: false, untrustedContentHint: false }, execute: async (input: unknown) => { if (!input || (input as { monitor?: string }).monitor !== "resident-services") throw new Error("Monitor is not allowlisted"); await runChecks(); return { monitor: "resident-services", status: "completed", result: "pass" }; } }, { signal: lifecycle.signal });
    return () => lifecycle.abort();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    fetch("/api/check", { cache: "no-store" }).then(response => response.ok ? response.json() : null).then(config => {
      const urls = [...(config?.fixtures || []).map((name: string) => `fixture://${name}`), ...(config?.hosts || []).map((host: string) => `https://${host}/`)];
      setAllowedTargets(urls);
      if (urls[0]) setTargetUrl(urls[0]);
    }).catch(() => undefined);
  }, []);

  function exportReport() {
    const report = { generatedAt: new Date().toISOString(), scope: "approved-targets-only", overall, targets: { uptime: "99.95%", p95Response: "750ms", brokenLinks: 0, recovery: "60s" }, results };
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2)], { type: "application/json" })); a.download = "civic-reliability-report.json"; a.click(); URL.revokeObjectURL(a.href);
    setNotice("Report exported."); setTimeout(() => setNotice(""), 3000);
  }

  return <main className="app-shell">
    <aside className={`sidebar ${mobileNav ? "open" : ""}`}>
      <div className="brand"><span className="brand-mark"><Radar size={21}/></span><div><strong>Civic Reliability</strong><small>AUTHORIZED LAB</small></div></div>
      <nav aria-label="Main navigation"><p className="nav-label">OPERATIONS</p>{nav.map(([label, Icon]) => <button key={label} className={active === label ? "active" : ""} onClick={() => { setActive(label); setMobileNav(false); }}><Icon size={18}/><span>{label}</span>{label === "Incidents" && <b>1</b>}</button>)}<p className="nav-label">ADMINISTRATION</p><button onClick={() => setShowRules(true)}><ShieldCheck size={18}/><span>Safety controls</span></button><button><Users size={18}/><span>Team & roles</span></button><button><Settings2 size={18}/><span>Settings</span></button></nav>
      <div className="scope-card"><div><LockKeyhole size={16}/><strong>Scope locked</strong></div><p>{allowedTargets.length ? `${allowedTargets.length} authorized target${allowedTargets.length === 1 ? "" : "s"}` : "No targets configured"}<br/>Internal checks use an outbound agent</p><button onClick={() => setShowRules(true)}>Review controls <ExternalLink size={13}/></button></div>
      <div className="user"><span>EW</span><div><strong>Dr. Elena Ward</strong><small>Program administrator</small></div><MoreHorizontal size={18}/></div>
    </aside>
    <section className="workspace">
      <header className="topbar"><button className="mobile-menu" onClick={() => setMobileNav(v => !v)} aria-label="Open navigation"><Menu size={21}/></button><div className="crumb"><span>Operations</span><span>/</span><strong>{active}</strong></div><label className="search"><Search size={17}/><input aria-label="Search monitors" placeholder="Search monitors, incidents, logs"/><kbd>⌘ K</kbd></label><button className="icon-btn" aria-label="Alerts"><BellRing size={18}/><i/></button><button className="role">Administrator <ChevronDown size={14}/></button></header>
      <div className="content">
        <div className="page-head"><div><div className="eyebrow"><span className="pulse"/> LIVE OPERATIONS · UTC</div><h1>Reliability overview</h1><p>Essential public services · authorized monitoring scope</p></div><div className="actions"><button className="secondary" onClick={exportReport}><Download size={16}/> Export report</button><button className="primary" onClick={runChecks} disabled={running}><RefreshCw size={16} className={running ? "spin" : ""}/>{running ? "Running…" : "Run checks"}</button></div></div>
        {notice && <div className="toast" role="status"><Check size={16}/>{notice}</div>}
        <section className="status-strip"><div className="system-state"><span className="state-icon"><ShieldCheck size={24}/></span><div><small>CURRENT STATE</small><strong>Operational with one issue</strong><p>Monitoring active · last run 14 seconds ago</p></div></div><div className="target"><span>30-DAY UPTIME</span><strong>99.97%</strong><em className="good">+0.02%</em></div><div className="target"><span>P95 RESPONSE</span><strong>486 ms</strong><em className="good">64 ms faster</em></div><div className="target"><span>OPEN INCIDENTS</span><strong>1</strong><em className="bad">3 broken links</em></div></section>
        <div className="grid-main"><section className="panel chart-panel"><div className="panel-head"><div><h2>Service performance</h2><p>30-day availability against the 99.95% objective</p></div><button>Last 30 days <ChevronDown size={14}/></button></div><div className="chart-summary"><div><span>Observed uptime</span><strong>99.97%</strong></div><div><span>Error budget remaining</span><strong>13m 9s</strong></div><div><span>Total checks</span><strong>8,640</strong></div></div><div className="chart" aria-label="Uptime trend chart"><div className="chart-labels"><span>100%</span><span>99.95%</span><span>99.90%</span></div><svg viewBox="0 0 720 170" preserveAspectRatio="none" role="img" aria-label="Uptime remained near target with a brief dip"><defs><linearGradient id="fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#24b7a4" stopOpacity=".26"/><stop offset="1" stopColor="#24b7a4" stopOpacity="0"/></linearGradient></defs><path className="area" d="M0 128 L65 110 L130 48 L196 59 L261 29 L327 42 L392 21 L458 33 L523 25 L589 14 L654 20 L720 15 L720 170 L0 170Z"/><path className="line" d="M0 128 L65 110 L130 48 L196 59 L261 29 L327 42 L392 21 L458 33 L523 25 L589 14 L654 20 L720 15"/><line x1="0" x2="720" y1="82" y2="82" className="threshold"/><circle cx="720" cy="15" r="5"/></svg><div className="dates"><span>Aug 14</span><span>Aug 20</span><span>Aug 26</span><span>Sep 1</span><span>Sep 7</span><span>Sep 12</span></div></div></section>
        <section className="panel report-card"><div className="panel-head"><div><h2>Reliability verdict</h2><p>Current reporting window</p></div><span className="fail-pill"><X size={13}/> FAIL</span></div><div className="score-ring"><svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="48"/><circle className="progress" cx="60" cy="60" r="48"/></svg><div><strong>5/6</strong><span>targets met</span></div></div><div className="verdict-list"><p><Check/>Uptime ≥ 99.95%<b>PASS</b></p><p><Check/>P95 response &lt; 750 ms<b>PASS</b></p><p><Check/>TLS validity &gt; 30 days<b>PASS</b></p><p className="failed"><X/>Broken links = 0<b>FAIL</b></p></div><button onClick={exportReport}><FileCheck2 size={16}/> Open full pass/fail report</button></section></div>
        <section className="panel results-panel"><div className="panel-head"><div><h2>Latest checks</h2><p>Timestamped evidence from the approved target set</p></div><div className="inline-controls"><select value={interval} onChange={e => setIntervalValue(e.target.value)} aria-label="Test interval"><option>1 minute</option><option>5 minutes</option><option>15 minutes</option><option>30 minutes</option></select><button onClick={() => setShowNew(true)}><Plus size={15}/> New monitor</button></div></div><div className="table-wrap"><table><thead><tr><th>STATUS</th><th>SERVICE / CHECK</th><th>RESULT</th><th>TARGET</th><th>UTC TIME</th><th>DETAIL</th></tr></thead><tbody>{results.map(r => <tr key={r.id}><td><span className={`result ${r.status}`}><CircleDot size={13}/>{r.status.toUpperCase()}</span></td><td><strong>{r.service}</strong><span>{r.type}</span></td><td><b>{r.value}</b></td><td>{r.target}</td><td className="mono">{r.time}</td><td><button className="detail" title={r.detail}>View evidence</button></td></tr>)}</tbody></table></div></section>
        <div className="bottom-grid"><section className="panel"><div className="panel-head"><div><h2>Synthetic journeys</h2><p>Scheduled public-service paths</p></div><button className="plain">Manage</button></div><div className="journey"><span><Globe2/></span><div><strong>Find and open a permit form</strong><small>4 steps · every 15 min</small></div><b className="warn-text">1.42 s</b></div><div className="journey"><span><KeyRound/></span><div><strong>Test-account sign in</strong><small>3 steps · every 30 min</small></div><b className="good-text">842 ms</b></div></section><section className="panel injection"><div className="panel-head"><div><h2>Controlled recovery</h2><p>Mock failures cannot reach production</p></div><span className="safety-badge"><LockKeyhole/>SAFE MODE</span></div><div className="fixture"><FlaskConical size={22}/><div><strong>Payment API fixture</strong><small>Local fixture · inject HTTP 503</small></div><button onClick={() => setFixtureArmed(v => !v)}>{fixtureArmed ? <X size={14}/> : <Play size={14}/>} {fixtureArmed ? "Disarm" : "Run exercise"}</button></div><p className="guardrail"><ShieldCheck/>The injection controller rejects every production hostname before execution.</p></section></div>
      </div>
    </section>
    {(showRules || showNew) && <div className="modal-backdrop" onMouseDown={() => { setShowRules(false); setShowNew(false); }}><section className="modal" onMouseDown={e => e.stopPropagation()} role="dialog" aria-modal="true" aria-label={showRules ? "Safety controls" : "New monitor"}><button className="modal-close" onClick={() => { setShowRules(false); setShowNew(false); }}><X/></button>{showRules ? <><span className="modal-icon"><ShieldCheck/></span><h2>Enforced safety controls</h2><p>Each target type uses the closest safe execution route.</p><ul><li><Check/>Public targets run from the hosted service after exact authorization.</li><li><Check/>Private and localhost targets run from an outbound-only internal agent.</li><li><Check/>Fixture targets are simulated in-process and make no network request.</li><li><Check/>Probe starts stay at the selected rate, never above 300 per second.</li><li><Check/>A durable target lease prevents overlapping runs from stacking traffic.</li></ul><button className="primary wide" onClick={() => setShowRules(false)}>Controls understood</button></> : <><span className="modal-icon"><Plus/></span><h2>Select an authorized monitor target</h2><p>Network targets require administrator configuration. Fixture targets remain local.</p><label>Authorized target<select value={targetUrl} onChange={e => setTargetUrl(e.target.value)} disabled={!allowedTargets.length}><option value="">{allowedTargets.length ? "Select a target" : "No targets configured"}</option>{allowedTargets.map(url => <option key={url} value={url}>{url.startsWith("fixture:") ? `${url} (local)` : new URL(url).hostname}</option>)}</select></label><label>Check type<select><option>HTTP + response time</option><option>DNS resolution</option><option>TLS validity</option><option>Broken links</option></select></label><label>Probe rate<select value={requestsPerSecond} onChange={e => setRequestsPerSecond(Number(e.target.value))}><option value="1">1 request/second</option><option value="2">2 requests/second</option><option value="5">5 requests/second</option><option value="10">10 requests/second</option><option value="100">100 requests/second</option><option value="300">300 requests/second</option></select></label><label>Interval<select value={interval} onChange={e => setIntervalValue(e.target.value)}><option>1 minute</option><option>5 minutes</option><option>15 minutes</option><option>30 minutes</option></select></label><button className="primary wide" disabled={!targetUrl} onClick={() => { setShowNew(false); setNotice(targetUrl ? "Authorized monitor selected." : "No target configured."); }}>Use target</button></>}</section></div>}
  </main>;
}
